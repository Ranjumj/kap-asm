import React from 'react';
import logo from './logo.svg';
import './App.css';
import UpcomingLessons from './components/UpcomingLessons';

function App() {
  return (
   <UpcomingLessons/>
  );
}

export default App;
