import React from 'react';
import Avatar from "../images/Avatar_old.png";


export default (props) =>{
    return (
        <div className="avatar-container">
            <img height={30} width={30} alt={props.alt} src={props.src}></img>
        </div>
    )
}

