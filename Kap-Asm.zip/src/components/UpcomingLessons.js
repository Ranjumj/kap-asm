import React from 'react';
import Avatar from './Avatar';
import DateFormat from "./DateFormat";
import channelData from '../assets/channel.json' 

function formatAMPM(date,addHour) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    // var strTime = hours + ':' + minutes + ' ' + ampm;
    return `${hours+addHour}:${minutes} ${ampm}`
  }


export default () => {

const processedData = channelData.concat().sort(function(a, b) {
    var dateA = new Date(a.time), dateB = new Date(b.time);
    return dateA - dateB;
});

const groupedData = [];
let tempGroup = [];

processedData.reduce((a,b,index)=> {
    if(new Date(a.time).setHours(0,0,0,0) === new Date(b.time).setHours(0,0,0,0)){
           tempGroup.push(b);
           if(index === processedData.length-1){
            groupedData.push(tempGroup);  
            tempGroup = [];
           }
    }else{
        if(tempGroup.length > 0){
            groupedData.push(tempGroup);
            tempGroup = [];
        }
        tempGroup.push(b);
    }
    return b;
},{time:new Date(1800)});

    return(
        <section>
            <div className="main">
                {groupedData.map((outer,index)=>{
                    return (
                       
                        <div className={"container"}>
                        <h5 className={"date-head"}> <DateFormat time ={outer[0].time}/> </h5>
                        {outer.map(inner => {
                           return( <div className="card-container">
                              <div className={"col-1"}>
                              <Avatar alt="subject image" src={inner.subjectPhotoUrl}></Avatar>
                              </div>
                              <div  className={"col-2"}>
                              <h6 className={"title-head"}>{inner.title}</h6>
                              <p className={"sub-description"}>{inner.description}</p>
                              </div>
                              <div  className={"col-3"}>
                              <Avatar alt="instructor image" src={inner.instructorPhotoUrl}></Avatar>
                              </div>
                              <div className={"col-4"}>
                               <p className="instructor-name">{inner.instructorName}</p>
                              </div>
                              <div className={"col-5"}>
                               <p className="sub-duration">{`${formatAMPM(new Date(inner.time),0)} - ${formatAMPM(new Date(inner.time),1)} IST`  }</p>
                              </div>
                              </div>)
                        }
                        )}
                        </div>
                    )
                })}
            </div>
        </section>
    )

}