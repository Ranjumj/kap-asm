import React from "react";


const DateFormater = (props) => {
var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];
var d = new Date(props.time);
var dayName = days[d.getDay()];
var monthName = months[d.getMonth()];
return (
    <p>
        {`${dayName},${monthName} ${d.getDate()}, ${d.getFullYear()}`}
    </p>
)
}

export default DateFormater;

