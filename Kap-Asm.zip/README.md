1. Project Set up
Type "npm install" inside project directory console.

2. Run the application
 Type "npm start" to run the application inside directory console.